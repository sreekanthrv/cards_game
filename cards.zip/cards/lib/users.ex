defmodule Users do
  defstruct name: nil, cards: nil, game_status: nil, score: 0, is_dealer: false
end
